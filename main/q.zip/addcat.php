<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<form action="savecat.php" method="post">
<center><h4><i class="icon-plus-sign icon-large"></i> Add Category</h4></center>
<hr>
<div id="ac">
<span>Category Name : </span><input type="text" style="width:265px; height:30px;" name="name" Required/><br>
<div style="float:right; margin-right:10px;">
<button class="btn btn-success btn-block btn-large" style="width:267px;"><i class="icon icon-save icon-large"></i> Save</button>
</div>
</div>
</form>
